import UIKit

var greeting = "Hello, playground"

extension StringProtocol {
    subscript(_ offset: Int)                     -> Element     { self[index(startIndex, offsetBy: offset)] }
}

struct NewString {
    var waveString = ""
}

func wave(_ y: String) -> [String] {
    if y == "" { return [String]() }
    var lower = y.lowercased()
    var result = [String]()
    for (index, val) in lower.enumerated() {
        if val == " " { continue }
        result.append(lower.prefix(index) +  (lower.prefix(index+1).last!.uppercased()) + lower.suffix(lower.count-index-1))
    }
  return result
}


wave("")
wave("Hello World")
