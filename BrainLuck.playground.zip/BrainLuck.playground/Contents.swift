import UIKit

func brainLuck(_ code: String, input: String) -> String {

    var index = 0
    var result = input
    enum Symbols {
        case ">", "<", "+", "-", ".", ",", "[", "]"
    }
    var output = ""
    
    while index != code.count {
        
        switch Symbols {
        case ">":
            index += 1
        case "<":
            index -= 1
        case "+":
            if result[index] == 255 {
                result[index] = 0
            } else {
            result[index] += 1
            }
        case "-":
            if result[index] == 0 {
                result[index] = 255
            } else {
            result[index] -= 1
            }
        case ".":
            output.append(String(result[index]))
            print(output)
        case ",":
            if result[index] == 255 {
                result[index] = 0
            } else {
            result[index] += 1
            }
        case "[":
            if result[index] == 0 {
                
                var openCloseCounter = 1
                
//                for result[index] in code {
//                    if code
//                }
                
                var numberOfOpenBraces = code.filter($0 == "[")
                var numberOfCloseBraces = code.filter($0 == "]")
                
                var indiciesOfOpenBraces = code.enumerated().filter({ $0.element == "[" }).map({ $0.offset })
                var indiciesOfClosedBraces = code.enumerated().filter({ $0.element == "]" }).map({ $0.offset })
            }
        }
        index += 1
    }
    
  return ""
}

var (code, input, solution) = (",+[-.,+]", "Codewars\(UnicodeScalar(255)!)", "Codewars")

print(brainLuck(code, input: input))

print("\(UnicodeScalar(0)!)")

print("\(UnicodeScalar(8)!)")

print("\(UnicodeScalar(9)!)")

print("\(UnicodeScalar(72)!)")

print("Codewars\(UnicodeScalar(0)!)")
