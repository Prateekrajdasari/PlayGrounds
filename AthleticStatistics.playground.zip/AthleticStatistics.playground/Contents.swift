import UIKit

let greeting = "Hello, playground"

func convertStringtoSeconds(str: String) -> Int {
    let strArray = str.components(separatedBy: "|").map{Int($0)}
    return ((strArray[0] ?? 0)*60*60) + ((strArray[1] ?? 0)*60) + (strArray[2] ?? 0)
}

func convertSecondstoString(seconds: Int) -> String {
    let hours = (seconds/60)/60
    let minutes = (seconds/60)%60
    let seconds = (seconds%60)%60
    return "\(String(format: "%02d", hours))|\(String(format: "%02d", minutes))|\(String(format: "%02d", seconds))"
}

func stat(_ strg: String) -> String {
    let secondsArray = strg.components(separatedBy: ",").map{convertStringtoSeconds(str: $0)}.sorted()
    let leastTime = secondsArray.first ?? 0
    let longestTime = secondsArray.last ?? 0
    let range = convertSecondstoString(seconds: longestTime - leastTime)
    let average = convertSecondstoString(seconds: secondsArray.reduce(0,+)/secondsArray.count)
    
    let median: Int = {
        if secondsArray.count%2 == 0 {
            return (secondsArray[secondsArray.count/2] + secondsArray[(secondsArray.count/2) + 1])/2
        } else {
            return secondsArray[secondsArray.count/2]
        }
    }()
    return "Range: \(range) Average: \(average) Median: \(convertSecondstoString(seconds: median))";
}

stat("02|15|59,02|47|16,02|17|20,02|32|34,02|32|34,02|17|17"   )

var  l = "02|15|59,02|47|16,02|17|20,02|32|34,02|32|34,02|17|17";
var sol = "Range: 00|31|17 Average: 02|27|10 Median: 02|24|57";
