var result = [Int]()

func sqInRect(_ lng: Int, _ wdth: Int) -> [Int]? {
    result = [Int]()
    if lng == wdth { return nil }
    cal(lng, width: wdth)
    print(result)
    return result
}

func cal (_ length: Int, width: Int) {
    
    if length == 0 || width == 0 {
        return
    }
    
    if length == width {
        result.append(length)
        return
    }
    
    let minNumber = length > width ? width : length
    let maxNumber = length < width ? width : length
    result.append(minNumber)
    let diff = maxNumber - minNumber
    result.append(diff)
    cal(minNumber-diff, width: diff)
}

sqInRect(5, 3)
