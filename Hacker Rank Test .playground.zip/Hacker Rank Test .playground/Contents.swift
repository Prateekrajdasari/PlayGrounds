
// First Question

print(isOpen(atTime: 940, marketHours: [930, 1600]))


func isOpen(atTime tradeTime: Int, marketHours: [Int]) -> Bool {
    let formatedTradeTime = timeFormatted(totalSeconds: tradeTime)
    let marketStartHours = timeFormatted(totalSeconds: marketHours[0])
    let marketEndHours = timeFormatted(totalSeconds: marketHours[1])
    return (formatedTradeTime.0 >= marketStartHours.0) && (formatedTradeTime.1 >= marketStartHours.1) && (formatedTradeTime.0 < marketEndHours.0)
}

 func timeFormatted(totalSeconds: Int) -> (Int, Int) {
     guard totalSeconds > 0 && totalSeconds < 2460 else { return (0,0) }
     let secInStr = String(totalSeconds)
     let minutes = secInStr.suffix(2)
     let hrs = secInStr.count > 3 ? secInStr.prefix(2) : secInStr.prefix(1)
     guard Int(minutes) ?? 0 < 60 && Int(hrs) ?? 0 < 24 else { return (0,0) }
     return (Int(hrs) ?? 0, Int(minutes) ?? 0)
}

// Second question

/* func findRateAndRoute(for currencyPair: String,
                      rates: [String: Decimal]) -> (rate: Decimal,
                                                    route: String) {
    var result = (Decimal(), "")
    let src1 = String(currencyPair.prefix(3))
    for item in rates.enumerated() {
        let key = item.element.key
        let val = item.element.value
        let first = key.prefix(3)
        let sec = key.suffix(3)
        var route = ""
        var value = Decimal()
        if first == src1 || first == sec {
            route += key
            value += val
        }
        result = (value,route)
    }
    return result
}

let forString = "USDGBP"
let rates: [String : Decimal] = ["USDEUR": 0.89,
                                 "EURGBP": 0.83]

findRateAndRoute(for: forString, rates: rates)
