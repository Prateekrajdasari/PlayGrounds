import UIKit

var greeting = "Hello, playground"

//func countDuplicates(_ s:String) -> Int {
//    var count = 0
//    var uniqueString = Array(Set(s.lowercased()))
//    if uniqueString.count == s.count { return 0 }
//    uniqueString.map { str in
//        count += s.lowercased().filter{$0 == str}.count > 1 ? 1 : 0
//    }
//  return count
//}

func countDuplicates(_ s:String) -> Int {
  return Dictionary(grouping: s, by: { $0.lowercased() }).filter { $0.value.count > 1 }.count
}

countDuplicates("indivisibility")
countDuplicates("aAbbcdeff")
countDuplicates("abcdef123")
countDuplicates("87056464565")
