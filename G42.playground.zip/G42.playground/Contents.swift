import UIKit

var greeting = "Hello, playground"

/*
 Given an array of integers A of size N and an integer B.
  
 College library has N bags,the ith book has A[i] number of pages.
  
 You have to allocate books to B number of students so that maximum number of pages alloted to a student is minimum.
  
 A book will be allocated to exactly one student.
 Each student has to be allocated at least one book.
 Allotment should be in contiguous order, for example: A student cannot be allocated book 1 and book 3, skipping book 2.
  
 Calculate and return that minimum possible number.
  
 NOTE: Return -1 if a valid assignment is not possible.
 */


/*
 For Example
  
 Input 1:
     A = [12, 34, 67, 90]
     B =   // Number of students
 Output 1:
     113
 Explanation 1:
     There are 2 number of students. Books can be distributed in following fashion :
         1) [12] and [34, 67, 90]
         Max number of pages is allocated to student 2 with 34 + 67 + 90 = 191 pages
         2) [12, 34] and [67, 90]
         Max number of pages is allocated to student 2 with 67 + 90 = 157 pages
 */
 
//1,1,1,1,1
//s:
//2,3

func NetworkCall() {
    
    struct Model: Codable { //Model
        
    }

let urlString = "http://...."
let url = URL(string: urlString)
    let urlRequest = URLRequest(url: url)

let urlsession = URLSession.shared

let dataTask = urlsession.dataTask(with: urlRequest) { [weak self] data, response, error in
        
        guard let weakself = self else {return}
        
        guard let data = data else { return}
        
        do {
            let jsondecoder = JSONDecoder()
            let responseModel = try jsondecoder.decode(Model.self, from: data)
            return responseModel
        } catch {
            return
        }
    }
    dataTask.resume()

}


class Single {
    static let shared = Single()
}

Single.shared
