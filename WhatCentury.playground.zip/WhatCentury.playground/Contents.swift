import UIKit

var greeting = "Hello, playground"

//func whatCentury1(_ year: String) -> String {
//
//    let yearNum = Int(year)!
//
//    let yearValue = yearNum % 1000 == 0 ? yearNum/100 : (yearNum % 100) == 0 ? yearNum/100 : yearNum/100 + 1
//
////    let yearValue = yearNum % 1000 == 0 ? yearNum/100 : (yearNum/100) + 1
//
//    func yearStringFunc() -> String {
//        switch yearValue % 10 {
//        case 1:
//            return "st"
//        case 2:
//            return "nd"
//        case 3:
//            return "rd"
//        default:
//            return "th"
//        }
//    }
//
//    let yearString = [11,12,13].contains(yearValue) ? "th" : yearStringFunc()
//
//    return "\(yearValue)\(yearString)"
//}

func whatCentury2(_ year: String) -> String {
    return NumberFormatter.localizedString(
      from: NSNumber(value: ceil(Double(year)!/100)),
      number: .ordinal)
}

extension Int {
  var spokenSuffix: String {
    let ones = self % 10
    let tens = (self / 10) % 10
      
    guard tens != 1 else { return "th" }
  
    switch ones {
    case 1: return "st"
    case 2: return "nd"
    case 3: return "rd"
    default: return "th"
    }
  }
}

func whatCentury(_ year: String) -> String {
  guard let year = Int(year) else { return "bad input" }
  let century = (year - 1) / 100 + 1
  return String(century) + century.spokenSuffix
}


whatCentury("1234")
